﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices; // iniFile

namespace Calendar
{
    public partial class Form1 : Form
    {
        public static string Parse(string events) // перебераю текст события
        {
            int index = events.IndexOf(",");
            Data.EVENT = null; Data.DATE = null; //iData.Count = 0;
            if (index > 0)
            {
                Data.Value = events;
                Data.EVENT = events.Remove(index);             // получаю текст без даты
                Data.DATE = events.Remove(0, index + 1);       // получаю дату без текста

                IFormatProvider culture = new System.Globalization.CultureInfo("ru-RU", true);
                DateTime dt = DateTime.Parse(Data.DATE, culture, System.Globalization.DateTimeStyles.AssumeLocal); ;
                iData.MM = Convert.ToInt32(dt.Month);  // Day
                iData.DD = Convert.ToInt32(dt.Day);    // Month
                iData.YYYY = Convert.ToInt32(dt.Year); // Year
                iData.Count = iData.Count + 1;   // количество event для массива DateTime
                
            }
            // MessageBox.Show("SelectedIndex  " + DataErr.Value);
            return Data.EVENT;
        }

        public static string ReadHol() // читаю hol в каленарь + подготовка для Parse
        {
            using (StreamReader str = new StreamReader(Data.FILENAME, System.Text.Encoding.Default))
            {
                string fgroup = "[";
                string line = null;
                iData.ValueStat = 0;
                //   List<string> nevent = new List<string> { }; // динамический массив
                List<string> ngroup = new List<string> { }; // динамический массив

                //string[] group = new string[5];
                int i = 0;
                while ((line = str.ReadLine()) != null)
                {
                    // MessageBox.Show(line);
                    if (line.IndexOf(fgroup) == 0 || line.IndexOf(fgroup) == 1)
                    {
                        ngroup.Add(line);
                        i++;
                        //var s = ngroup.ElementAt(2); var d = ngroup[1];
                    }
                    else
                    {
                        Parse(line.Remove(line.LastIndexOf('=')));  // обрезаю строку до = с конца
                    }

                }

                return Data.Valuechg;

            }
        }

       /* public static string ImportHol()
        {
            ReadHol();   //из нее запускаю Parse()
            DateTime DATE = new DateTime(iData.YYYY, iData.MM, iData.DD);
            DateTime[] VacationDates = { myVacation1, myVacation2 };
            monthCalendar1.BoldedDates = VacationDates;
            MessageBox.Show(" ");
            return null;
        }*/

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            Data.FILENAME = "calendar.txt"; //"@calendar.txt";
            Data.PATHDIR = Application.StartupPath + "\\";

            ReadHol();   //из нее запускаю Parse()
            DateTime DATE = new DateTime(iData.YYYY, iData.MM, iData.DD);
            monthCalendar1.AddBoldedDate(DATE);
            monthCalendar1.UpdateBoldedDates();
            //aData.Value = DateTime(iData.YYYY, iData.MM, iData.DD, 0, 0, 0, 0) ;Array.add
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Text = DateTime.Now.ToString("dd.MM.yyyy   HH:mm:ss"); //+ DateTime.Now.Hour.ToString("00") + ":" + DateTime.Now.Minute.ToString("00");  dateTime.ToShortDateString()
        }

        private void button1_Click(object sender, EventArgs e) // form2 show 
        {
            Form F2 = new Form2();
            F2.Show(); 
            // Application.Run(new Form2());
            //Form2.ActiveForm.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReadHol();

           // int i =0;
            //DateTime myVacation1 = new DateTime(iData.YYYY, iData.MM, iData.DD);
           // DateTime myVacation2 = new DateTime(2017, 12, 4);
            //DateTime[] VacationDates = {myVacation1, myVacation2};
            //monthCalendar1.BoldedDates = VacationDates;
                               
            DateTime[] VacationDates = new DateTime[iData.Count]; //количество строк в файле System.IO.File.ReadAllLines(Data.FILENAME).Length
            for (int i = 0; i <= iData.Count-1; i++) 
            { 
            VacationDates[i] = new DateTime(iData.YYYY+1, iData.MM-10, iData.DD+i);
            }
            this.monthCalendar1.AnnuallyBoldedDates = VacationDates;
          
            //monthCalendar1.BoldedDates = VacationDates;
            iData.Count = 0; 
        }
        
        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e) // test + 
        {
            this.monthCalendar1.ShowWeekNumbers = true; 
            this.monthCalendar1.AnnuallyBoldedDates =
            new System.DateTime[] { new System.DateTime(2008, 12, 8, 0, 0, 0, 0) };

            this.monthCalendar1.MonthlyBoldedDates =
           new System.DateTime[] {new System.DateTime(2017, 12, 1, 0, 0, 0, 0),
                                  new System.DateTime(2002, 1, 17, 0, 0, 0, 0)};

            this.monthCalendar1.BoldedDates = new System.DateTime[] { new System.DateTime(2017, 11, 11, 0, 0, 0, 0) };

            //this.monthCalendar1.FirstDayOfWeek = System.Windows.Forms.Day.Monday;
            //this.monthCalendar1.MaxDate = new System.DateTime(2010, 12, 31, 0, 0, 0, 0);
            //this.monthCalendar1.MinDate = new System.DateTime(2016, 2, 2, 0, 0, 0, 0);

            this.monthCalendar1.TitleBackColor = System.Drawing.Color.Purple;
            this.monthCalendar1.TitleForeColor = System.Drawing.Color.Yellow;
            monthCalendar1.TitleBackColor = System.Drawing.Color.Blue;
            monthCalendar1.TrailingForeColor = System.Drawing.Color.Red;
            monthCalendar1.TitleForeColor = System.Drawing.Color.Yellow;
           /*this.ClientSize = new System.Drawing.Size(920, 566);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.textBox1, this.monthCalendar1 });
            this.Text = "Month Calendar Example";*/
            
/* System.DateTime today = this.monthCalendar2.TodayDate;
            int vacationMonth = today.Month + 1;
            int vacationYear = today.Year;

            if (vacationMonth > 12) { vacationMonth = 1; vacationYear++; }
            this.monthCalendar2.SelectionStart =
            new System.DateTime(vacationYear, vacationMonth, today.Day); */
        }

        private void button5_Click(object sender, EventArgs e) //Test Arry 
        {
            string[] evEvent = { "aaa", "aaa", "aaaa", "asaaa", "aaas", "aaa" };
            for (int i = 0; i < evEvent.Length; i++)
            {
                if (evEvent[i] == "aaa")
                {
                    MessageBox.Show(evEvent[i] + " " + i.ToString());
                }
            }
        }

 

       





    }

}
