﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Calendar
{
     static class Data
     {
         public static string Value { get; set; } // http://www.cyberforum.ru/windows-forms/thread110436.html  для получения данных Data.Value = "111";
         public static string EVENT { get; set; }
         public static string DATE { get; set; }
         public static string YYYY { get; set; }
         public static string MM { get; set; }
         public static string DD{ get; set; } 
         public static string ValueStat { get; set; }
         public static string Valuechg { get; set; }
         public static string FILENAME { get; set; }
         public static string PATHDIR { get; set; }
         public static string ValueErr { get; set; } 
     }

     static class iData
     {
         public static int Value { get; set; }
         public static Int32 YYYY { get; set; }
         public static Int32 MM { get; set; }
         public static Int32 DD { get; set; } 
         public static int ValueStat { get; set; }  // Form2.checkedListBox2:     0- new, 1- edit
         public static int Count { get; set; }      // количестао event
         public static int Valuechg { get; set; }
         public static int ValueErr { get; set; }
     }

     static class aData
     {
         //public static string[][] Event { get; set; }
         public static DateTime[] DATE { get; set; } 
     }

    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        /// 
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.EnableVisualStyles();
            Application.Run(new Form1());
        //    Application.Run(new Form2());
            
        }
    }
}
