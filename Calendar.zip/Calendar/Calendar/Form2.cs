﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices; // iniFile

namespace Calendar
{

    public partial class Form2 : Form
    {         
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) //new group 
        {
            string Value, Value1 = "";
            int cc = 0; //совпадения 
            Value1 = Microsoft.VisualBasic.Interaction.InputBox("Name", "groupe adding", "birthday", 20, 10);
            if (Value1 != "")
            {
                for (int i = 0; i < checkedListBox1.Items.Count; i++)
                {
                    Value =checkedListBox1.Items[i].ToString();
                    if (Value == Value1) cc = 1;
                }
                if (cc == 0) checkedListBox1.Items.Add(Value1); // if there are no matches
            }
        }

        private void button2_Click(object sender, EventArgs e) //edit group 
        {
            string Value1 = "";
            int i = checkedListBox1.SelectedIndex;
            
            if (i >= 0) {
                Value1 = Microsoft.VisualBasic.Interaction.InputBox("Name", "groupe editing", checkedListBox1.Items[i].ToString(), 20, 10);
                checkedListBox1.Items[checkedListBox1.SelectedIndex] = Value1;
            }
        }

        private void button3_Click(object sender, EventArgs e) //delete group 
        {
            checkedListBox1.Items.Remove(checkedListBox1.SelectedItem); 
        }

        private void button6_Click(object sender, EventArgs e) //new event 
        {
            iData.ValueStat = 0; //0 - new
            Form F3 = new Form3();
            F3.Owner = this;
            F3.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e) //edit event
        {
            int i = checkedListBox2.SelectedIndex;
            if (i >= 0)
            {
                iData.ValueStat = 1; //1 - edit
                Data.Value = checkedListBox2.Items[i].ToString();
                //checkedListBox2.Items.Remove(i);
                Form F3 = new Form3();
                F3.Owner = this;
                F3.ShowDialog();
                // TEST listBox1.Items.Add(checkedListBox2.Items[checkedListBox2.SelectedIndex].ToString() + " Index: " + checkedListBox2.SelectedIndex.ToString()); 
                i = -1;
            }
        }

        private void button4_Click(object sender, EventArgs e) //delete event
        {
           // MessageBox.Show(checkedListBox2.GetItemCheckState(checkedListBox2.SelectedIndex).ToString() + ".");
            int i = checkedListBox2.SelectedIndex;
            if (i >= 0)
            {
                if (checkedListBox2.GetItemCheckState(i).ToString() == "Checked")
                {
                    checkedListBox2.Items.Remove(checkedListBox2.SelectedItem);
                }
                i = -1;
            }
        }

        private void checkedListBox2_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            //listBox1.Items.Clear();
            if (e.NewValue == CheckState.Checked)
            {
                listBox1.Items.Add(checkedListBox2.Items[checkedListBox2.SelectedIndex].ToString());
            }
            else
            {
                listBox1.Items.Remove(checkedListBox2.Items[checkedListBox2.SelectedIndex].ToString());
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e) //close write to file
        {
           
       }

        private void button7_Click(object sender, EventArgs e) // Import
        {
            
            INIManager manager = new INIManager("C:\\Users\\svmarchenko\\Documents\\Visual Studio 2010\\Projects\\Calendar\\Calendar\\bin\\Debug\\calendar.txt"); //Data.PATHDIR + Data.FILENAME); //Создание объекта, для работы с файлом
            string name = manager.GetPrivateString("birthday", ""); //Получить значение по ключу "" из секции birthday
            int x = -1; x++;
                    checkedListBox2.Items[x] = name;
            //string name = manager.GetPrivateString("birthday", ""); //Получить значение по ключу "" из секции birthday

            // manager.WritePrivateString("birthday", "Событие,12/25/2017", "0"); //Записать значение по ключу "" в секции birthday
            // manager.WritePrivateString("remember", "Памятка,12/22/2017", "1");
            // manager.WritePrivateString("remember", "Памятка,11/22/2017", "1"); // 1 = Checked ; 0 = unChecked
            // for (int i = 0; i < checkedListBox1.Items.Count; i++)
            }


        private void button8_Click(object sender, EventArgs e) // Export
        {
            INIManager manager = new INIManager(Data.PATHDIR + Data.FILENAME); //Создание объекта, для работы с файлом
            File.WriteAllText(Data.FILENAME, null);
                for (int x = 0; x < checkedListBox2.Items.Count; x++)
                {
                    manager.WritePrivateString(checkedListBox1.Items[0].ToString(), checkedListBox2.Items[x].ToString(), checkedListBox1.Items[0].ToString());
                }
        } 
    }



}


public class INIManager
{
    //Конструктор, принимающий путь к INI-файлу
    public INIManager(string aPath)
    {
        path = aPath;
    }

    //Конструктор без аргументов (путь к INI-файлу нужно будет задать отдельно)
    public INIManager() : this("") { }

    //Возвращает значение из INI-файла (по указанным секции и ключу) 
    public string GetPrivateString(string aSection, string aKey)
    {
        //Для получения значения
        StringBuilder buffer = new StringBuilder(SIZE);

        //Получить значение в buffer
        GetPrivateString(aSection, aKey, null, buffer, SIZE, path);

        //Вернуть полученное значение
        return buffer.ToString();
    }

    //Пишет значение в INI-файл (по указанным секции и ключу) 
    public void WritePrivateString(string aSection, string aKey, string aValue)
    {
        //Записать значение в INI-файл
        WritePrivateString(aSection, aKey, aValue, path);
    }

    //Возвращает или устанавливает путь к INI файлу
    public string Path { get { return path; } set { path = value; } }

    //Поля класса
    private const int SIZE = 1024; //Максимальный размер (для чтения значения из файла)
    private string path = null; //Для хранения пути к INI-файлу

    //Импорт функции GetPrivateProfileString (для чтения значений) из библиотеки kernel32.dll
    [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileString")]
    private static extern int GetPrivateString(string section, string key, string def, StringBuilder buffer, int size, string path);

    //Импорт функции WritePrivateProfileString (для записи значений) из библиотеки kernel32.dll
    [DllImport("kernel32.dll", EntryPoint = "WritePrivateProfileString")]
    private static extern int WritePrivateString(string section, string key, string str, string path);
}  // iniFile http://plssite.ru/csharp/csharp_ini_files_article.html  

//bool b = (emptyStr == nullStr);
//this.Text = checkedListBox1.SelectedItems();
//i = checkedListBox1.CheckedItems.Count;


//Form FormName = new Form3();
//FormName.Show();
//Value1 = Data.Value;
//this.Value1 = Form3.TextBox icrosoft.VisualBasic.Interaction.InputBox("Name", "event adding", "BD", 20, 10);
//if (Value1 != "") checkedListBox2.Items.Add(Value1);