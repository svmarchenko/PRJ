﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Calendar
{
    public partial class Form3 : Form
    {
        static string date1 = null; //общие

        /*public static string Parse(string events) // перебераю текст
        {
            int index = events.IndexOf(",");
            string text = "";
            if (index > 0)
            {
                text = events.Remove(index);
                evTxt = text;                           // получаю текст без даты
                dateTxt = events.Remove(0, index + 1);    // получаю дату без текста
            }
            else
            {
               // MessageBox.Show("function Parse Error: SelectedIndex  " + DataErr.Value);
            }
               // MessageBox.Show("SelectedIndex  " + DataErr.Value);
            return text;
        }*/

        public static string Parse(string events) // перебераю текст события
        {
            int index = events.IndexOf(",");
            Data.EVENT = null; Data.DATE = null;
            if (index > 0)
            {
                Data.Value = events;
                Data.EVENT = events.Remove(index);             // получаю текст без даты
                Data.DATE = events.Remove(0, index + 1);       // получаю дату без текста

                IFormatProvider culture = new System.Globalization.CultureInfo("ru-RU", true);
                DateTime dt = DateTime.Parse(Data.DATE, culture, System.Globalization.DateTimeStyles.AssumeLocal); ;
                        iData.MM = Convert.ToInt32(dt.Month);  // Day
                        iData.DD = Convert.ToInt32(dt.Day);    // Month
                        iData.YYYY = Convert.ToInt32(dt.Year); // Year
            }
            // MessageBox.Show("SelectedIndex  " + DataErr.Value);
            return Data.EVENT;
        }

        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e) // test event
        {
            if (textBox1.Text != "") button1.Enabled = true;
            else button1.Enabled = false; 
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) // dateTime 
        {
           // DateTime dateTime = dateTimePicker1.Value;
           // date1 = dateTime.ToShortDateString();
            // ///int i = dateTimePicker1.Value.Date.ToString().Length - 12; // удаляю время 12:00:00 AM
            // ///date1 = dateTimePicker1.Value.Date.ToString().Remove(i);
        }

        private void button2_Click(object sender, EventArgs e) // Cancel 
        {
            this.Close();
        } 

        private void button1_Click(object sender, EventArgs e) // OK  передаю данные из дочерней формы Form3
        {
            Form2 F2 = this.Owner as Form2;
            if (F2 != null)
            {
                //dateTimePicker1.Text          
                date1 = this.textBox1.Text + "," + dateTimePicker1.Text; //dateTimePicker1.Text а не data1 иначе необходимо обязательно нажимать на календарь.
                if (iData.ValueStat == 0) F2.checkedListBox2.Items.Add(date1);
                if (iData.ValueStat == 1) F2.checkedListBox2.Items[F2.checkedListBox2.SelectedIndex] = date1;
      //          F2.listBox1.Items.Add(F2.checkedListBox2.Items[F2.checkedListBox2.SelectedIndex].ToString());
            }
            this.Close();
        }

        private void Form3_Activated(object sender, EventArgs e)
        {
            dateTimePicker1.CustomFormat = "d/MM/yyyy";
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            if (iData.ValueStat == 1) button2.Enabled = false;
            if (iData.ValueStat == 0)
            {
                Data.Value = null;
                button2.Enabled = true;
                dateTimePicker1.Value = DateTime.Now;
            } 

            Form2 F2 = this.Owner as Form2;
            if (F2 != null)
            {
                if (Data.Value != null)  // edit 
                {
                    string txt = Parse(Data.Value);
                    this.textBox1.Text = Data.EVENT;
                    this.dateTimePicker1.Text = iData.MM.ToString() +"/"+ iData.DD.ToString() +"/"+ iData.YYYY.ToString();
                    date1 ="";

                }
            }

        }
    }
}
